{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2024-12-18 02:11",
    "md5": "89950c7db3272f9ba90f83eb3bc6fc62",
    "count": "7116"
  },
  "chnroute_maxmind": {
    "name": "chnroute_maxmind.txt",
    "date": "2024-11-19 16:05",
    "md5": "41302df69ece45fe11d3e9ddcad2c47e",
    "count": "7212",
    "count_ip": "345532148",
    "source": "maxmind",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/geolite2_country/country_cn.netset"
  },
  "chnroute_ipip": {
    "name": "chnroute_ipip.txt",
    "date": "2024-11-19 16:05",
    "md5": "4dc3943cb26f84c28cbdcbd46ff3399d",
    "count": "7395",
    "count_ip": "354951706",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "chnroute_17mon": {
    "name": "chnroute_17mon.txt",
    "date": "2024-11-19 16:05",
    "md5": "4e37080ae9dddb3349e5491cf6d137b0",
    "count": "6885",
    "count_ip": "354433392",
    "source": "17mon",
    "url": "https://github.com/17mon/china_ip_list"
  },
  "chnroute_misakaio": {
    "name": "chnroute_misakaio.txt",
    "date": "2024-12-22 02:11",
    "md5": "d7163c5c716410b6dfcbce5bd4a827e1",
    "count": "4219",
    "count_ip": "285520896",
    "source": "misakaio",
    "url": "https://github.com/misakaio/chnroutes2/blob/master/chnroutes.txt"
  },
  "chnroute_cnisp": {
    "name": "chnroute_cnisp.txt",
    "date": "2024-11-19 16:04",
    "md5": "4e37080ae9dddb3349e5491cf6d137b0",
    "count": "6885",
    "count_ip": "354433392",
    "source": "cnisp",
    "url": "https://github.com/gaoyifan/china-operator-ip"
  },
  "chnroute_apnic": {
    "name": "chnroute_apnic.txt",
    "date": "2024-12-20 02:11",
    "md5": "d41d8cd98f00b204e9800998ecf8427e",
    "count": "0",
    "count_ip": "",
    "source": "apnic",
    "url": "http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2024-12-22 02:11",
    "md5": "4b162cda1abb013db99fd98fb7c6a3b9",
    "count": "8412",
    "count_ip": "376140529",
    "source": "fancyss",
    "url": "https://github.com/fastbash/fancyss/tree/3.0/rules"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2024-12-19 02:11",
    "md5": "62c792f5f1ed19a6e86198ecad4e0094",
    "count": "93987"
  },
  "apple_china": {
    "name": "apple_china.txt",
    "date": "2024-11-19 16:05",
    "md5": "216ccd6e184055ba6133687a1c42aa3b",
    "count": "174"
  },
  "google_china": {
    "name": "google_china.txt",
    "date": "2024-11-19 16:05",
    "md5": "6899bb37a930b7b4c89528035c90f5f4",
    "count": "191"
  },
  "cdn_test": {
    "name": "cdn_test.txt",
    "date": "2024-11-19 16:05",
    "md5": "84b034525bca6b60fbffb68dc8fbb9cd",
    "count": "87"
  }
}
