#!/bin/sh

MODULE=planesocks


run(){
	env -i PATH="${PATH}" "$@"
}

__md5_file(){
    md5sum "$1" | awk '{print $1}' 2>/dev/null
}

get_domain_name(){
	echo "$1" | sed -e 's|^[^/]*//||' -e 's|/.*$||' | awk -F ":" '{print $1}'
}

__valid_ip() {
	# 验证是否为ipv4或者ipv6地址，是则正确返回，不是返回空值
	local format_4
	format_4=$(echo "$1" | grep -Eo "([0-9]{1,3}[\.]){3}[0-9]{1,3}$")
	if [ -n "${format_4}" ]; then
		echo "${format_4}"
		return 0
	else
		echo ""
		return 1
	fi
}