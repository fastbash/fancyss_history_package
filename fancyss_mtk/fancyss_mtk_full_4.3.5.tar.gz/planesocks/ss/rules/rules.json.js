{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2024-11-25 09:15",
    "md5": "ad2ab2000ecc9dca5c983b3e77301bdd",
    "count": "7124"
  },
  "chnroute_maxmind": {
    "name": "chnroute_maxmind.txt",
    "date": "2024-11-19 16:05",
    "md5": "41302df69ece45fe11d3e9ddcad2c47e",
    "count": "7212",
    "count_ip": "345532148",
    "source": "maxmind",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/geolite2_country/country_cn.netset"
  },
  "chnroute_ipip": {
    "name": "chnroute_ipip.txt",
    "date": "2024-11-19 16:05",
    "md5": "4dc3943cb26f84c28cbdcbd46ff3399d",
    "count": "7395",
    "count_ip": "354951706",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "chnroute_17mon": {
    "name": "chnroute_17mon.txt",
    "date": "2024-11-19 16:05",
    "md5": "4e37080ae9dddb3349e5491cf6d137b0",
    "count": "6885",
    "count_ip": "354433392",
    "source": "17mon",
    "url": "https://github.com/17mon/china_ip_list"
  },
  "chnroute_misakaio": {
    "name": "chnroute_misakaio.txt",
    "date": "2024-12-03 02:11",
    "md5": "17f5edf3b28e9115ec06879ccaa8d1e8",
    "count": "4199",
    "count_ip": "285669376",
    "source": "misakaio",
    "url": "https://github.com/misakaio/chnroutes2/blob/master/chnroutes.txt"
  },
  "chnroute_cnisp": {
    "name": "chnroute_cnisp.txt",
    "date": "2024-11-19 16:04",
    "md5": "4e37080ae9dddb3349e5491cf6d137b0",
    "count": "6885",
    "count_ip": "354433392",
    "source": "cnisp",
    "url": "https://github.com/gaoyifan/china-operator-ip"
  },
  "chnroute_apnic": {
    "name": "chnroute_apnic.txt",
    "date": "2024-12-02 02:11",
    "md5": "d41d8cd98f00b204e9800998ecf8427e",
    "count": "0",
    "count_ip": "",
    "source": "apnic",
    "url": "http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2024-12-03 02:11",
    "md5": "ad2389bbf69f43aefa241417ef353003",
    "count": "8399",
    "count_ip": "376123377",
    "source": "fancyss",
    "url": "https://github.com/fastbash/fancyss/tree/3.0/rules"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2024-12-03 02:11",
    "md5": "3ee6be84758e631d1b72275a42fad941",
    "count": "94152"
  },
  "apple_china": {
    "name": "apple_china.txt",
    "date": "2024-11-19 16:05",
    "md5": "216ccd6e184055ba6133687a1c42aa3b",
    "count": "174"
  },
  "google_china": {
    "name": "google_china.txt",
    "date": "2024-11-19 16:05",
    "md5": "6899bb37a930b7b4c89528035c90f5f4",
    "count": "191"
  },
  "cdn_test": {
    "name": "cdn_test.txt",
    "date": "2024-11-19 16:05",
    "md5": "84b034525bca6b60fbffb68dc8fbb9cd",
    "count": "87"
  }
}
